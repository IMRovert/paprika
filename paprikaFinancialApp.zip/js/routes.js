angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('login', {
    url: '/page2',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('signup', {
    url: '/page3',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

  .state('mainMenu', {
    url: '/page4',
    templateUrl: 'templates/mainMenu.html',
    controller: 'mainMenuCtrl'
  })

  .state('payBillS', {
    url: '/page5',
    templateUrl: 'templates/payBillS.html',
    controller: 'payBillSCtrl'
  })

  .state('recordTransactionS', {
    url: '/page6',
    templateUrl: 'templates/recordTransactionS.html',
    controller: 'recordTransactionSCtrl'
  })

  .state('graphicalData', {
    url: '/page7',
    templateUrl: 'templates/graphicalData.html',
    controller: 'graphicalDataCtrl'
  })

  .state('export', {
    url: '/page8',
    templateUrl: 'templates/export.html',
    controller: 'exportCtrl'
  })

  .state('import', {
    url: '/page9',
    templateUrl: 'templates/import.html',
    controller: 'importCtrl'
  })

  .state('transactionHistory', {
    url: '/page10',
    templateUrl: 'templates/transactionHistory.html',
    controller: 'transactionHistoryCtrl'
  })

  .state('bills', {
    url: '/page11',
    templateUrl: 'templates/bills.html',
    controller: 'billsCtrl'
  })

  .state('checkBalance', {
    url: '/page12',
    templateUrl: 'templates/checkBalance.html',
    controller: 'checkBalanceCtrl'
  })

  .state('profile', {
    url: '/page13',
    templateUrl: 'templates/profile.html',
    controller: 'profileCtrl'
  })

$urlRouterProvider.otherwise('/page4')


});